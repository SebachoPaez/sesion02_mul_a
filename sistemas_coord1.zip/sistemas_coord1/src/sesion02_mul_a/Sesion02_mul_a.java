package sesion02_mul_a;

public class Sesion02_mul_a {

    public static void main(String[] args) {
        Cartesiana a, b, c= new Cartesiana(6, 11);
    }
    
}
